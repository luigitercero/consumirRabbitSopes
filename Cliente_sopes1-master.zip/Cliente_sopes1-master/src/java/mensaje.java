/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kevin
 */
public class mensaje {
    String user;
    String mensaje;
    String fecha;

    public mensaje(String user, String mensaje, String fecha) {
        this.user = user;
        this.mensaje = mensaje;
        this.fecha = fecha;
    }
}
